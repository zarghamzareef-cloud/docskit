@echo off
title DOCs' Kit - try it
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 ( start "" https://nodejs.org & echo Install Node.js LTS first, then run this again. & pause & exit /b 1 )
if not exist node_modules call npm install
call npm start
