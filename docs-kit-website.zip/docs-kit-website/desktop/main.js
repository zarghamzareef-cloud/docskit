// DOCs' Kit desktop shell · published by Dr Zargham Zareef and Zaheem Aftab
const { app, BrowserWindow, shell, Menu } = require('electron');
const path = require('path');
const fs = require('fs');
const http = require('http');

const OPENABLE = /\.(pdf|png|jpe?g|gif|webp|bmp|svg|txt|md|csv|json|xml|html?|docx|xlsx|xls|pptx)$/i;
const fileFromArgs = argv => argv.slice(1).find(a => !a.startsWith('-') && OPENABLE.test(a) && fs.existsSync(a));
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'application/javascript', '.mjs': 'application/javascript', '.css': 'text/css', '.json': 'application/json',
  '.wasm': 'application/wasm', '.gz': 'application/octet-stream', '.traineddata': 'application/octet-stream', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf' };

let win = null, pending = fileFromArgs(process.argv), origin = '', portP = null;

// The viewer is served from a private local address so the PDF engine, OCR workers and offline data all load normally.
function serve(root) {
  return new Promise(resolve => {
    const srv = http.createServer((req, res) => {
      let u = '/';
      try { u = decodeURIComponent(new URL(req.url, 'http://localhost').pathname); } catch (_) {}
      if (u === '/') u = '/index.html';
      const f = path.normalize(path.join(root, u));
      if (!f.startsWith(root)) { res.writeHead(403); res.end(); return; }
      fs.readFile(f, (err, data) => {
        if (err) { res.writeHead(404); res.end(); return; }
        res.writeHead(200, { 'Content-Type': MIME[path.extname(f).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
        res.end(data);
      });
    });
    const tryPort = p => {
      srv.once('error', () => tryPort(0));
      srv.listen(p, '127.0.0.1', () => resolve(srv.address().port));
    };
    tryPort(47813); // a fixed port keeps your settings, signature and recent files between launches
  });
}

function send(file) {
  if (!file || !win) return;
  const go = () => win.webContents.send('open-path', file);
  if (win.webContents.isLoading()) win.webContents.once('did-finish-load', go); else go();
}

async function createWindow() {
  const port = await (portP || (portP = serve(path.join(__dirname, 'app'))));
  origin = 'http://127.0.0.1:' + port;
  win = new BrowserWindow({
    width: 1360, height: 860, minWidth: 760, minHeight: 520, show: false,
    backgroundColor: '#f3f4f6', title: "DOCs' Kit",
    icon: path.join(__dirname, 'build', 'icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: false, spellcheck: true }
  });
  if (process.platform === 'darwin') {
    // macOS needs an app menu for Quit, copy and paste, and window shortcuts
    Menu.setApplicationMenu(Menu.buildFromTemplate([{ role: 'appMenu' }, { role: 'editMenu' }, { role: 'viewMenu' }, { role: 'windowMenu' }]));
  } else Menu.setApplicationMenu(null);
  win.once('ready-to-show', () => { win.maximize(); win.show(); });
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^(https?|mailto):/.test(url) && !url.startsWith(origin)) shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith(origin)) { e.preventDefault(); if (/^(https?|mailto):/.test(url)) shell.openExternal(url); } });
  win.loadURL(origin + '/index.html');
  win.webContents.once('did-finish-load', () => { if (pending) { send(pending); pending = null; } });
  win.on('closed', () => { win = null; });
}

if (!app.requestSingleInstanceLock()) { app.quit(); }
else {
  app.setAppUserModelId('com.zarghamzareef.docskit');
  app.on('second-instance', (_e, argv) => {
    if (win) { if (win.isMinimized()) win.restore(); win.focus(); send(fileFromArgs(argv)); }
  });
  app.on('open-file', (e, f) => { e.preventDefault(); if (win) send(f); else pending = f; });
  app.whenReady().then(createWindow);
  app.on('window-all-closed', () => app.quit());
  app.on('activate', () => { if (!win) createWindow(); });
}
