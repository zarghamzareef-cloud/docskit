DOCS' KIT 2.0 - Windows and Mac program
==========================================
Published by Dr Zargham Zareef and Zaheem Aftab · zargham.zareef@icloud.com

EASIEST WAY (about 10 minutes, only once)
-----------------------------------------
1. Unzip this folder somewhere simple, for example  C:\DOCsKit
2. Double-click  BUILD.bat
     - If Node.js is missing, the download page opens. Install the "LTS"
       version (accept the defaults), then double-click BUILD.bat again.
     - It downloads the build tools, packs everything inside the program,
       and builds the installer. Leave the black window open until it says Done.
3. A folder opens with  DOCs-Kit-Setup.exe
   Double-click it to install. You get a desktop icon and a Start menu entry.

Want to try it before building?  Double-click  TRY-IT.bat

Want one file that runs without installing (for a USB stick)?
  Open a terminal in this folder and run:  npm run dist:portable

NO-INSTALL OPTION (build online, free GitHub account) - also makes the Mac app
-------------------------------------------------------------------------------
1. Create a new repository on github.com and upload all files from this folder
   (including the hidden .github folder).
2. Open the "Actions" tab. "Build Windows and Mac apps" runs by itself
   (or press "Run workflow").
3. When it turns green, open the run and download:
     "DOCs-Kit-Windows"  the installer and a portable .exe
     "DOCs-Kit-Mac"      DOCs-Kit-Mac.dmg for Apple silicon and Intel Macs

MAC
---
Build on a Mac yourself: install Node.js LTS, open Terminal in this folder and run
    npm install
    npm run dist:mac
The app appears in  dist/mac-universal . The online build above also makes a .dmg.
First launch on a Mac: open the app once, then System Settings -> Privacy & Security
-> "Open Anyway". (Apple shows this for any app without a paid Apple developer ID.)

AFTER INSTALLING
----------------
- Start screen: big buttons for every task and your recent files. Click the logo to see it again.
- Ribbon tabs at the top: Home, Comment, Fill & Sign, Pages, Convert, Protect, AI, Class, View, Help.
  Right-click any button to add it to the Quick Access Toolbar beside the logo.
- Search box (Ctrl+K): type what you want, e.g. "make smaller", "rotate", "page 12", or a question for the AI.
- Several documents open at once in tabs. F4 shows thumbnails, bookmarks and the comments list.
- OCR (Convert or Home tab) reads scanned pages. English works offline; other languages download once.
- AI Assistant (top right) summarises, explains, translates and quizzes. It needs internet.
- Make it your PDF reader: right-click any PDF -> Open with -> Choose another app
  -> DOCs' Kit -> tick "Always use this app".

IF SOMETHING GOES WRONG
-----------------------
- "Windows protected your PC": click More info -> Run anyway.
  (This warning appears for any program without a paid code-signing certificate.)
- Download errors during BUILD.bat: check your internet and run it again.
- Anything else: copy the red text from the black window and send it for help.

TO UPDATE LATER
---------------
Replace viewer.html with a newer DOCs-Kit.html (keep the name viewer.html)
and double-click BUILD.bat again.
