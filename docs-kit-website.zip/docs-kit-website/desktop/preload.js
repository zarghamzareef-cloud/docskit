// Gives the viewer safe access to files you open with DOCs' Kit (double-click, Open with, recent files).
const { contextBridge, ipcRenderer, webUtils } = require('electron');
const fs = require('fs');
const path = require('path');
let handler = null; const queue = [];
function deliver(p) {
  try {
    const buf = fs.readFileSync(p), bytes = new Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength).slice();
    const name = path.basename(p);
    if (handler) handler(name, bytes, p); else queue.push([name, bytes, p]);
  } catch (e) { console.error('Could not open', p, e); }
}
ipcRenderer.on('open-path', (_e, p) => deliver(p));
contextBridge.exposeInMainWorld('docsDesktop', {
  onOpen(cb) { handler = cb; queue.splice(0).forEach(([n, b, p]) => cb(n, b, p)); },
  openPath(p) { if (typeof p === 'string' && fs.existsSync(p)) deliver(p); },
  pathOf(file) { try { return webUtils && webUtils.getPathForFile ? webUtils.getPathForFile(file) : (file && file.path) || ''; } catch (_) { return ''; } }
});
