// Builds app/ : copies the viewer and downloads the PDF engine, tools, fonts and the English OCR engine once,
// so the installed program works offline.
const fs = require('fs'), path = require('path'), https = require('https');
const root = path.join(__dirname, '..'), app = path.join(root, 'app');
const LIBS = {
  'lib/pdf.min.js': 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js',
  'lib/pdf.worker.min.js': 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js',
  'lib/jszip.min.js': 'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js',
  'lib/xlsx.full.min.js': 'https://cdn.sheetjs.com/xlsx-0.20.3/package/dist/xlsx.full.min.js',
  'lib/pdf-lib.min.js': 'https://cdnjs.cloudflare.com/ajax/libs/pdf-lib/1.17.1/pdf-lib.min.js',
  'ocr/tesseract.min.js': 'https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js'
};
const OCR_WORKER = 'https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/worker.min.js';
const CORE_VERSIONS = ['5.1.1', '5.1.0', '5.0.0'];
const CORE_FILES = ['tesseract-core-simd-lstm.wasm.js', 'tesseract-core-lstm.wasm.js', 'tesseract-core-relaxedsimd-lstm.wasm.js'];
const ENG = ['https://cdn.jsdelivr.net/npm/@tesseract.js-data/eng/4.0.0_best_int/eng.traineddata.gz', 'https://tessdata.projectnaptha.com/4.0.0_best/eng.traineddata.gz', 'https://tessdata.projectnaptha.com/4.0.0/eng.traineddata.gz'];
const FONTS_CSS = 'https://fonts.googleapis.com/css2?family=Poppins:wght@500;600&family=Roboto:wght@400;500;700&family=Great+Vibes&family=Dancing+Script:wght@600&family=Caveat:wght@600&display=swap';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36';

function get(url) {
  return new Promise((res, rej) => {
    https.get(url, { headers: { 'User-Agent': UA } }, r => {
      if (r.statusCode >= 300 && r.statusCode < 400 && r.headers.location) { r.resume(); return res(get(new URL(r.headers.location, url).href)); }
      if (r.statusCode !== 200) { r.resume(); return rej(new Error(url + ' -> HTTP ' + r.statusCode)); }
      const c = []; r.on('data', d => c.push(d)); r.on('end', () => res(Buffer.concat(c)));
    }).on('error', rej).setTimeout(60000, function () { this.destroy(new Error('timed out: ' + url)); });
  });
}
async function cached(file, url) {
  if (fs.existsSync(file) && fs.statSync(file).size > 1000) return true;
  console.log('  downloading', path.relative(app, file));
  const data = await get(url); fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, data); return true;
}
const tryGet = async (file, urls) => { for (const u of urls) { try { await cached(file, u); return true; } catch (e) { /* try the next mirror */ } } return false; };

(async () => {
  console.log("Preparing DOCs' Kit…");
  fs.mkdirSync(app, { recursive: true });
  let html = fs.readFileSync(path.join(root, 'viewer.html'), 'utf8');
  for (const [rel, url] of Object.entries(LIBS)) { await cached(path.join(app, rel), url); html = html.split(url).join('./' + rel); }

  // OCR: reading engine and English language data, so scans can be read without internet
  const ocr = {};
  if (await tryGet(path.join(app, 'ocr/worker.min.js'), [OCR_WORKER])) ocr.workerPath = './ocr/worker.min.js';
  for (const v of CORE_VERSIONS) {
    let ok = 0;
    for (const f of CORE_FILES) { if (await tryGet(path.join(app, 'ocr/core', f), ['https://cdn.jsdelivr.net/npm/tesseract.js-core@' + v + '/' + f])) ok++; }
    if (ok >= 2) { ocr.corePath = './ocr/core'; break; }
  }
  if (await tryGet(path.join(app, 'ocr/lang/eng.traineddata.gz'), ENG)) ocr.langPath = './ocr/lang';
  if (ocr.workerPath && ocr.corePath) {
    html = html.replace('<script', '<script>window.DV_OCR=' + JSON.stringify(ocr) + ';</script>\n<script');
    console.log('  OCR works offline' + (ocr.langPath ? ' for English' : '') + '. Other languages download on first use.');
  } else console.warn('  OCR engine could not be packed; OCR will download it on first use (needs internet).');

  try {
    let css = (await get(FONTS_CSS)).toString('utf8'), i = 0;
    for (const m of [...css.matchAll(/url\((https:[^)]+)\)/g)]) { const f = 'fonts/font' + (i++) + '.woff2'; await cached(path.join(app, f), m[1]); css = css.split(m[1]).join('./' + f.slice(6)); }
    fs.mkdirSync(path.join(app, 'fonts'), { recursive: true }); fs.writeFileSync(path.join(app, 'fonts', 'fonts.css'), css);
    html = html.replace(/<link[^>]+fonts\.googleapis\.com[^>]*>/g, '<link rel="stylesheet" href="./fonts/fonts.css">');
  } catch (e) { console.warn('  Fonts could not be downloaded (system fonts will be used):', e.message); }

  fs.writeFileSync(path.join(app, 'index.html'), html);
  console.log('Ready: app/ prepared.');
})().catch(e => { console.error('\nPreparation failed. Check your internet connection and run it again.\n', e.message); process.exit(1); });
