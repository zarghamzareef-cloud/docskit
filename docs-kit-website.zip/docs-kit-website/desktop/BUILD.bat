@echo off
title Building DOCs' Kit
cd /d "%~dp0"
echo.
echo  ===== DOCs' Kit - build the Windows installer =====
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo  Node.js is not installed yet.
  echo  The download page will open. Install the LTS version, then run BUILD.bat again.
  start "" https://nodejs.org
  pause
  exit /b 1
)
echo  Step 1 of 2: getting the build tools. The first time takes a few minutes...
call npm install
if errorlevel 1 (
  echo.
  echo  Something went wrong. Check your internet connection and run BUILD.bat again.
  pause
  exit /b 1
)
echo.
echo  Step 2 of 2: building the installer...
call npm run dist
if errorlevel 1 (
  echo.
  echo  The build did not finish. Copy the red text above and send it for help.
  pause
  exit /b 1
)
echo.
echo  Done! Double-click DOCs-Kit-Setup.exe in the folder that just opened.
start "" "%~dp0dist"
pause
