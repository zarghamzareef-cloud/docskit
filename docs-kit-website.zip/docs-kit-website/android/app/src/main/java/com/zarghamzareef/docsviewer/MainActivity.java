package com.zarghamzareef.docsviewer;

import android.app.Activity;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * DOCs' Kit for Android, by Dr Zargham Zareef and Zaheem Aftab.
 * The app is the same single-page viewer used on the web and on Windows, shown in a WebView.
 * Pages are served from the app's own files under a private https address so storage and workers behave normally.
 */
public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String HOME = "https://" + HOST + "/index.html";
    private static final int PICK_FILE = 4101;
    private static final Map<String, String> MIME = new HashMap<>();
    static {
        MIME.put("html", "text/html"); MIME.put("js", "application/javascript"); MIME.put("css", "text/css");
        MIME.put("png", "image/png"); MIME.put("jpg", "image/jpeg"); MIME.put("svg", "image/svg+xml");
        MIME.put("json", "application/json"); MIME.put("wasm", "application/wasm"); MIME.put("woff2", "font/woff2");
        MIME.put("mjs", "application/javascript"); MIME.put("jpeg", "image/jpeg"); MIME.put("gif", "image/gif");
        MIME.put("webp", "image/webp"); MIME.put("ico", "image/x-icon"); MIME.put("woff", "font/woff"); MIME.put("ttf", "font/ttf");
        MIME.put("txt", "text/plain");
    }

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private boolean pageReady = false;
    private Intent pendingIntent;
    private View fullView;
    private WebChromeClient.CustomViewCallback fullCallback;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);

        web.addJavascriptInterface(new Bridge(), "DocsAndroid");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (!HOST.equals(u.getHost())) return null;
                String path = u.getPath();
                if (path == null || path.equals("/") || path.isEmpty()) path = "/index.html";
                try {
                    InputStream in = getAssets().open("www" + path);
                    String ext = path.contains(".") ? path.substring(path.lastIndexOf('.') + 1).toLowerCase() : "";
                    String mime = MIME.containsKey(ext) ? MIME.get(ext) : "application/octet-stream";
                    return new WebResourceResponse(mime, "UTF-8", in);
                } catch (IOException e) {
                    return new WebResourceResponse("text/plain", "UTF-8", 404, "Not found", new HashMap<String, String>(), null);
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) {
                    toast("No app can open this link.");
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                if (pendingIntent != null) {
                    Intent it = pendingIntent;
                    pendingIntent = null;
                    deliver(it);
                }
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            // Camera for the scanner: Android asks the person once, then the page may use it.
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    boolean wantsCamera = false;
                    for (String r : request.getResources()) if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) wantsCamera = true;
                    if (!wantsCamera) { request.deny(); return; }
                    if (Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(new String[] { PermissionRequest.RESOURCE_VIDEO_CAPTURE });
                    } else {
                        pendingCamera = request;
                        requestPermissions(new String[] { Manifest.permission.CAMERA }, ASK_CAMERA);
                    }
                });
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                if (params != null && params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                }
                try {
                    startActivityForResult(Intent.createChooser(i, "Choose a file"), PICK_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    toast("No file browser found.");
                    return false;
                }
                return true;
            }

            // Full-screen reading: the page asks for full screen, Android shows it edge to edge.
            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (fullView != null) { callback.onCustomViewHidden(); return; }
                fullView = view;
                fullCallback = callback;
                ((ViewGroup) getWindow().getDecorView()).addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            }

            @Override
            public void onHideCustomView() {
                if (fullView == null) return;
                ((ViewGroup) getWindow().getDecorView()).removeView(fullView);
                fullView = null;
                getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
                if (fullCallback != null) fullCallback.onCustomViewHidden();
                fullCallback = null;
            }
        });

        pendingIntent = getIntent();
        web.loadUrl(HOME);
    }

    private PermissionRequest pendingCamera;
    private static final int ASK_CAMERA = 7;

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code != ASK_CAMERA || pendingCamera == null) return;
        if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) pendingCamera.grant(new String[] { PermissionRequest.RESOURCE_VIDEO_CAPTURE });
        else pendingCamera.deny();
        pendingCamera = null;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (pageReady) deliver(intent); else pendingIntent = intent;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_FILE || fileCallback == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK && data != null) {
            ClipData clip = data.getClipData();
            if (clip != null && clip.getItemCount() > 0) {
                result = new Uri[clip.getItemCount()];
                for (int k = 0; k < clip.getItemCount(); k++) result[k] = clip.getItemAt(k).getUri();
            } else if (data.getData() != null) {
                result = new Uri[] { data.getData() };
            }
        }
        fileCallback.onReceiveValue(result);
        fileCallback = null;
    }

    @Override
    public void onBackPressed() {
        if (fullView != null) {
            web.evaluateJavascript("document.fullscreenElement && document.exitFullscreen()", null);
            return;
        }
        web.evaluateJavascript("(function(){var v=document.querySelector('.veil:not([hidden])');if(v){document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true}));return 'closed';}return 'none';})()",
            value -> { if (value == null || !value.contains("closed")) super.onBackPressed(); });
    }

    /** Hands a PDF that was opened with, or shared to, DOCs' Kit over to the page. */
    private void deliver(Intent it) {
        if (it == null) return;
        Uri u = null;
        String action = it.getAction();
        if (Intent.ACTION_VIEW.equals(action)) u = it.getData();
        else if (Intent.ACTION_SEND.equals(action)) u = it.getParcelableExtra(Intent.EXTRA_STREAM);
        if (u == null) return;
        final Uri uri = u;
        it.setAction(Intent.ACTION_MAIN);
        new Thread(() -> {
            try {
                byte[] bytes = readAll(uri);
                String name = nameOf(uri);
                String b64 = Base64.encodeToString(bytes, Base64.NO_WRAP);
                String js = "window.__docsAndroidOpen && window.__docsAndroidOpen(" + JSONObject.quote(name) + "," + JSONObject.quote(b64) + ")";
                runOnUiThread(() -> web.evaluateJavascript(js, null));
            } catch (Exception e) {
                toast("Could not open that file.");
            }
        }).start();
    }

    private byte[] readAll(Uri uri) throws IOException {
        try (InputStream in = getContentResolver().openInputStream(uri); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            if (in == null) throw new IOException("no stream");
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toByteArray();
        }
    }

    private String nameOf(Uri uri) {
        String name = null;
        try (Cursor c = getContentResolver().query(uri, new String[] { OpenableColumns.DISPLAY_NAME }, null, null, null)) {
            if (c != null && c.moveToFirst()) name = c.getString(0);
        } catch (Exception ignored) { }
        if (name == null) name = uri.getLastPathSegment();
        if (name == null || name.isEmpty()) name = "document.pdf";
        return name;
    }

    private void toast(String msg) {
        runOnUiThread(() -> Toast.makeText(this, msg, Toast.LENGTH_LONG).show());
    }

    /** Called from the page: window.DocsAndroid.save(name, mime, base64). Saves into Downloads. */
    private class Bridge {
        @JavascriptInterface
        public String save(String name, String mime, String b64) {
            try {
                byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
                String safe = name.replaceAll("[\\\\/:*?\"<>|]", "_");
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.MediaColumns.DISPLAY_NAME, safe);
                    cv.put(MediaStore.MediaColumns.MIME_TYPE, mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
                    cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    cv.put(MediaStore.MediaColumns.IS_PENDING, 1);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    if (uri == null) return "no space for the file";
                    try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                        if (os == null) return "could not write";
                        os.write(bytes);
                    }
                    cv.clear();
                    cv.put(MediaStore.MediaColumns.IS_PENDING, 0);
                    getContentResolver().update(uri, cv, null, null);
                } else {
                    File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                    if (dir == null) return "storage not available";
                    if (!dir.exists() && !dir.mkdirs()) return "storage not available";
                    try (FileOutputStream fo = new FileOutputStream(new File(dir, safe))) { fo.write(bytes); }
                }
                return "ok";
            } catch (Exception e) {
                return e.getMessage() == null ? "error" : e.getMessage();
            }
        }

        // Print a PDF through Android's own print service (any printer the phone knows, or Save as PDF).
        @JavascriptInterface
        public String print(String name, String b64) {
            try {
                final byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
                final String job = (name == null || name.isEmpty() ? "DOCs Kit" : name).replaceAll("[\\\\/:*?\"<>|]", "_");
                runOnUiThread(() -> {
                    PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                    if (pm == null) { toast("Printing is not available on this device."); return; }
                    pm.print(job, new PrintDocumentAdapter() {
                        @Override
                        public void onLayout(PrintAttributes oldA, PrintAttributes newA, CancellationSignal cancel, LayoutResultCallback cb, Bundle extras) {
                            if (cancel.isCanceled()) { cb.onLayoutCancelled(); return; }
                            cb.onLayoutFinished(new PrintDocumentInfo.Builder(job + ".pdf").setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).build(), true);
                        }
                        @Override
                        public void onWrite(PageRange[] pages, ParcelFileDescriptor dest, CancellationSignal cancel, WriteResultCallback cb) {
                            try (OutputStream out = new FileOutputStream(dest.getFileDescriptor())) {
                                out.write(bytes);
                                cb.onWriteFinished(new PageRange[] { PageRange.ALL_PAGES });
                            } catch (Exception e) {
                                cb.onWriteFailed(e.getMessage());
                            }
                        }
                    }, null);
                });
                return "ok";
            } catch (Exception e) {
                return e.getMessage() == null ? "unknown problem" : e.getMessage();
            }
        }

        @JavascriptInterface
        public String platform() {
            return "android";
        }
    }
}
