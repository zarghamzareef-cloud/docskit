# DOCs' Kit

![DOCs' Kit preview](images/preview.jpg)

**A free PDF reader and editor for students, teachers and doctors.** Made by Dr Zargham Zareef and Zaheem Aftab.

Scan pages with your camera into clean PDFs, present full screen (pen tools, page bar, book view), draw smart shapes, read, highlight and annotate (with a floating pen toolbar and a whiteboard), sign forms, read scanned pages with OCR, turn any PDF into practice MCQs (offline or with any AI), ask an AI study assistant, and organize, convert, compress and protect PDFs. Your documents open on your device and are not uploaded to us; text leaves it only when you use the AI or online search. See the [privacy policy, terms and licences](legal.html).

## Get it

Download from the **Releases** section on the right:

| Device | File |
|---|---|
| Windows 10 and 11 | `DOCs-Kit-Setup.exe` (installer) or `DOCs-Kit-Portable.exe` (no install) |
| Mac (macOS 11+, Apple silicon and Intel) | `DOCs-Kit-Mac.dmg` |
| Android 7+ | `DOCs-Kit-Android.apk` |
| Any web browser, including iPhone and iPad | `DOCs-Kit.html`, or *Open in browser* on the website |

The apps are not signed with a paid certificate yet, so your device may warn you the first time. Download only from Releases and check `SHA256SUMS.txt` if you like. Android is not available in countries that require registered developers (from Sept 2026: Brazil, Indonesia, Singapore, Thailand): use the browser version there.


- **Windows:** "Windows protected your PC" → **More info** → **Run anyway**.
- **Mac:** open the app once, then **System Settings → Privacy & Security → Open Anyway**.
- **Android:** allow your browser to **Install unknown apps**; if Play Protect asks, choose **Install anyway**.

## What is in this repository

| Path | What it is |
|---|---|
| `index.html` | The download page (GitHub Pages serves it) |
| `legal.html` | Privacy policy, terms of use and open-source licences |
| `THIRD-PARTY-NOTICES.txt` | Full licence texts of the open-source parts |
| `app.html` | The whole app in one file |
| `images/` | Screenshots and icon for the download page |
| `desktop/` | The Windows and Mac app (Electron) that wraps `app.html` |
| `android/` | The Android app (a WebView that wraps `app.html`) |
| `.github/workflows/release.yml` | Builds the Windows, Mac and Android downloads and publishes them as a release whenever `app.html`, `desktop/` or `android/` changes |

To release a new version: replace `app.html`, raise `"version"` in `desktop/package.json` (for example to `2.0.1`) and `versionCode`/`versionName` in `android/app/build.gradle`, and commit. The builds run by themselves and a new release appears within about 20 minutes. See `HOW-TO-PUBLISH.txt` for keeping one Android signing key between versions.

## Credits

Built with [pdf.js](https://github.com/mozilla/pdf.js), [pdf-lib](https://github.com/Hopding/pdf-lib), [Tesseract.js](https://github.com/naptha/tesseract.js), [JSZip](https://github.com/Stuk/jszip), [SheetJS](https://sheetjs.com) and [Electron](https://www.electronjs.org), all open source.

© 2026 Dr Zargham Zareef and Zaheem Aftab · zargham.zareef@icloud.com · DOCs' Kit is free to use and provided as is, without warranty. All rights reserved, except the open-source parts, which keep their own licences (see `THIRD-PARTY-NOTICES.txt`).

## Sample file
`sample/Sample-MCQs-CC0.pdf` is a short practice file written for this project and released under CC0 1.0 (public domain). Open it, then press MCQs to try the question maker. It is for practice only and is not medical advice.

## ♥ Support
DOCs' Kit is free and will stay free. If it helps you, you can support Dr Zargham Zareef and Zaheem Aftab with PayPal: scan the code below or open [this link](https://www.paypal.com/qrcodes/p2pqrc/3FP9GDFZEWNJC). Support is optional and does not unlock anything.

<img src="images/support-qr.png" width="200" alt="PayPal QR code to support DOCs' Kit">
